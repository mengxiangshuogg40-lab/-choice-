document.getElementById('scanBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab.url.includes('amazon.com/s')) {
    alert('Please open an Amazon.com search results page first.');
    return;
  }
  chrome.tabs.sendMessage(tab.id, { action: 'scan' });
});

document.getElementById('exportBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { action: 'export' });
});
