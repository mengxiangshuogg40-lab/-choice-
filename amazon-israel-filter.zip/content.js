/**
 * Amazon Israel Filter — Content Script
 *
 * 双通道策略:
 *   Channel A: 搜索卡片内联文字解析 (快, 0 个额外请求)
 *   Channel B: fetch 详情页解析 (慢, 仅 Channel A 不确定时触发)
 *
 * 分类: best/good/bad/unknown
 */
(function () {
  'use strict';

  const CONCURRENCY = 4;
  const CACHE_TTL    = 600_000;
  const SCAN_DELAY   = 2000;

  const cache  = new Map();
  let lastResults = [];
  let isScanning  = false;

  // ============================================================
  //  UTIL
  // ============================================================

  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const escapeHtml = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  function getASIN(card) {
    return card.getAttribute('data-asin') || '';
  }

  function getCardLink(card) {
    const a = card.querySelector('a[href*="/dp/"], a[href*="/product/"]');
    if (!a) return null;
    const href = a.getAttribute('href');
    if (!href) return null;
    try { return new URL(href, location.origin).href.replace(/\/ref=.*/, ''); }
    catch(e) { return null; }
  }

  function parseASIN(url) {
    const m = url?.match(/\/dp\/([A-Z0-9]{10})/);
    return m ? m[1] : null;
  }

  function getCardTitle(card) {
    const el = card.querySelector('h2 span, h2 .a-text-normal, [class*="title"] .a-text-normal, h2 a');
    return el ? norm(el.textContent) : '';
  }

  function getCardPrice(card) {
    const el = card.querySelector('.a-price .a-offscreen, .a-price-whole, [class*="price"] .a-offscreen');
    return el ? norm(el.textContent) : '';
  }

  // ============================================================
  //  CHANNEL A — 卡片内联解析
  // ============================================================

  function parseCardInline(card) {
    const deliverySelectors = [
      '[data-cy="delivery-recipe"]',
      'span[class*="delivery"]',
      'div[class*="delivery"]',
      'span[class*="shipping"]',
      'div[class*="shipping"]',
      '[class*="prime-delivery"]',
      'span[aria-label*="delivery"]',
      'span[aria-label*="shipping"]',
      'span[aria-label*="deliver"]',
    ];

    let deliveryText = '';
    for (const sel of deliverySelectors) {
      for (const el of card.querySelectorAll(sel)) {
        const t = norm(el.textContent);
        if (t.length > 3) deliveryText += ' ' + t;
      }
    }

    if (!deliveryText.trim()) {
      const cardText = norm(card.textContent || '');
      const idx = cardText.search(/(delivery|shipping|import\s*fee|arrives|FREE\s*delivery)/i);
      if (idx >= 0) {
        deliveryText = cardText.slice(Math.max(0, idx - 20), Math.min(cardText.length, idx + 200));
      } else {
        deliveryText = cardText;
      }
    }

    return parseShippingText(deliveryText);
  }

  function parseShippingText(text) {
    const t = text.toLowerCase();

    let freeShipping = false;
    for (const p of [
      /free\s*(international\s*)?(shipping|delivery)/i,
      /free\s*delivery/i,
      /arrives.*free/i,
      /FREE\s+delivery/i,
    ]) {
      if (p.test(t)) { freeShipping = true; break; }
    }

    let importFees = null;
    if (/no\s*import\s*(fees?|fee)\s*deposit/i.test(t)) {
      importFees = 0;
    } else if (/\bimport\s*(fees?|fee)\s*deposit\s*:?\s*\$?0\.?0?0?\b/i.test(t)) {
      importFees = 0;
    } else {
      const m = t.match(/\bimport\s*(fees?|fee)\s*deposit\s*:?\s*\$(\d+\.?\d{0,2})/i);
      if (m) importFees = parseFloat(m[2]);
    }

    return { freeShipping, importFees };
  }

  // ============================================================
  //  CHANNEL B — fetch 详情页
  // ============================================================

  async function fetchDetailPage(asin) {
    try {
      const resp = await fetch(`https://www.amazon.com/dp/${asin}`, {
        credentials: 'omit',
        headers: { 'Accept': 'text/html', 'User-Agent': navigator.userAgent },
      });
      if (!resp.ok) return null;
      return resp.text();
    } catch (e) {
      console.warn(`[AIF] fetch failed ${asin}:`, e.message);
      return null;
    }
  }

  function parseDetailHTML(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const bodyText = (doc.body?.textContent || '').replace(/\s+/g, ' ');

    const blocks = [];
    doc.body?.querySelectorAll(
      '[id*="delivery"],[id*="shipping"],[class*="delivery"],[class*="shipping"],' +
      '[id*="import"],[class*="import"],#mir-layout-DELIVERY_BLOCK'
    ).forEach(el => blocks.push(norm(el.textContent)));

    const combined = bodyText + ' ' + blocks.join(' ');

    let price = '';
    const priceEl = doc.querySelector('.a-price .a-offscreen, #priceblock_ourprice, .a-price-whole');
    if (priceEl) price = norm(priceEl.textContent);

    return { ...parseShippingText(combined), price };
  }

  // ============================================================
  //  CLASSIFY
  // ============================================================

  function classify(freeShipping, importFees) {
    const taxFree  = importFees === 0;
    const shipFree = freeShipping;
    if (taxFree && shipFree) return 'best';
    if (taxFree || shipFree) return 'good';
    if (importFees !== null && importFees > 0) return 'bad';
    return 'unknown';
  }

  // ============================================================
  //  SCAN
  // ============================================================

  async function scanCard(card) {
    const asin = getASIN(card) || parseASIN(getCardLink(card));
    if (!asin) {
      return { card, asin: '', category: 'unknown', freeShipping: false, importFees: null, title: getCardTitle(card), price: getCardPrice(card), source: 'none' };
    }
    if (cache.has(asin)) return { card, ...cache.get(asin) };

    const inline = parseCardInline(card);
    const inlineSufficient = inline.freeShipping === true || inline.importFees !== null;

    let result;
    if (inlineSufficient) {
      result = { asin, category: classify(inline.freeShipping, inline.importFees), freeShipping: inline.freeShipping, importFees: inline.importFees, source: 'card' };
    } else {
      const html = await fetchDetailPage(asin);
      if (!html) {
        result = { asin, category: classify(inline.freeShipping, inline.importFees), freeShipping: inline.freeShipping, importFees: inline.importFees, source: 'card(fb)' };
      } else {
        const detail = parseDetailHTML(html);
        result = { asin, category: classify(detail.freeShipping, detail.importFees), freeShipping: detail.freeShipping, importFees: detail.importFees, source: 'detail' };
        result.price = detail.price;
      }
    }

    result.title = getCardTitle(card);
    result.price = result.price || getCardPrice(card);

    cache.set(asin, result);
    return { card, ...result };
  }

  async function scanAll(cards) {
    const queue = cards.slice();
    let done = 0;
    const total = queue.length;
    const results = [];

    async function worker() {
      while (queue.length) {
        const card = queue.shift();
        const r = await scanCard(card);
        results.push(r);
        done++;
        showProgress(done, total);
      }
    }

    await Promise.all(Array.from({ length: CONCURRENCY }, () => worker()));

    // 按 DOM 顺序排
    results.sort((a, b) => a.card.compareDocumentPosition(b.card) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
    return results;
  }

  // ============================================================
  //  UI — 标签
  // ============================================================

  const LABEL_MAP = {
    best:    { text: 'Best', color: '#fff', bg: '#1b8a2e' },
    good:    { text: 'Good', color: '#fff', bg: '#e6a817' },
    bad:     { text: 'Bad',  color: '#fff', bg: '#c0392b' },
    unknown: { text: '?',    color: '#fff', bg: '#8e8e8e' },
  };

  function addLabel(card, result) {
    removeLabel(card);
    const cfg = LABEL_MAP[result.category] || LABEL_MAP.unknown;

    const label = document.createElement('div');
    label.className = `__amzn_il_label __amzn_il_label--${result.category}`;
    label.setAttribute('data-category', result.category);
    label.style.cssText = `
      position:absolute;top:0;left:0;z-index:99;
      background:${cfg.bg};color:${cfg.color};
      font:bold 11px/1.4 Arial,sans-serif;
      padding:3px 8px;border-radius:0 0 6px 0;
      pointer-events:none;white-space:nowrap;
      box-shadow:0 1px 3px rgba(0,0,0,0.15);
    `;

    const parts = [cfg.text];
    if (result.freeShipping) parts.push('免邮');
    if (result.importFees === 0) parts.push('免税');
    label.textContent = parts.join(' · ');
    label.title = `Free Shipping: ${result.freeShipping?'Yes':'No'}\nImport Fees: ${result.importFees===null?'?':result.importFees===0?'$0':'$'+result.importFees.toFixed(2)}\nSource: ${result.source}`;

    if (getComputedStyle(card).position === 'static') card.style.position = 'relative';
    card.appendChild(label);
  }

  function removeLabel(card) {
    const el = card.querySelector('.__amzn_il_label');
    if (el) el.remove();
  }

  // ============================================================
  //  UI — 摘要面板 (始终显示)
  // ============================================================

  let summaryEl = null;

  function showPanel(html) {
    removePanel();
    summaryEl = document.createElement('div');
    summaryEl.id = '__amzn_il_summary';
    summaryEl.innerHTML = html;
    document.body.appendChild(summaryEl);
  }

  function removePanel() {
    if (summaryEl) { summaryEl.remove(); summaryEl = null; }
  }

  function showLoaded(count) {
    showPanel(`
      <div style="position:fixed;top:10px;right:10px;z-index:99999;background:#146eb4;color:#fff;padding:6px 12px;border-radius:6px;font:12px/1.5 Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,0.2);">
        🇮🇱 AIF loaded · ${count} products · <a id="__amzn_il_scannow" style="color:#ff0;cursor:pointer;text-decoration:underline;">Scan now</a>
      </div>
    `);
    const btn = document.getElementById('__amzn_il_scannow');
    if (btn) btn.onclick = run;
  }

  function showSummary(results) {
    const cnt = { best:0, good:0, bad:0, unknown:0 };
    results.forEach(r => cnt[r.category]++);

    showPanel(`
      <div style="position:fixed;top:10px;right:10px;z-index:99999;background:#fff;border:2px solid #ccc;border-radius:8px;padding:10px 14px;min-width:220px;font:12px/1.6 Arial,sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.15);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <strong>🇮🇱 AIF Results</strong>
          <button id="__amzn_il_close" style="background:none;border:none;cursor:pointer;font-size:16px;line-height:1;">&times;</button>
        </div>
        <div>
          <span style="color:#1b8a2e;">■ Best ${cnt.best}</span>
          <span style="color:#e6a817;margin-left:8px;">■ Good ${cnt.good}</span>
          <span style="color:#c0392b;margin-left:8px;">■ Bad ${cnt.bad}</span>
          <span style="color:#8e8e8e;margin-left:8px;">■ ? ${cnt.unknown}</span>
        </div>
        <div style="margin-top:8px;display:flex;gap:6px;">
          <button id="__amzn_il_rescan" style="flex:1;padding:5px;background:#146eb4;color:#fff;border:none;border-radius:4px;cursor:pointer;">Rescan</button>
          <button id="__amzn_il_exp" style="flex:1;padding:5px;background:#eee;border:1px solid #ccc;border-radius:4px;cursor:pointer;">Export</button>
        </div>
      </div>
    `);
    document.getElementById('__amzn_il_close').onclick = removePanel;
    document.getElementById('__amzn_il_rescan').onclick = run;
    document.getElementById('__amzn_il_exp').onclick = () => exportJSON(results);
  }

  // ============================================================
  //  UI — 进度
  // ============================================================

  function showProgress(done, total) {
    let el = document.getElementById('__amzn_il_progress');
    if (!el) {
      el = document.createElement('div');
      el.id = '__amzn_il_progress';
      el.style.cssText = 'position:fixed;bottom:16px;right:16px;z-index:99999;background:#146eb4;color:#fff;padding:8px 14px;border-radius:6px;font:12px/1.5 Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,0.2);';
      document.body.appendChild(el);
    }
    el.textContent = `Scanning ${done}/${total}...`;
    if (done >= total) setTimeout(() => el.remove(), 2500);
  }

  function exportJSON(results) {
    const data = results.map(r => ({ asin: r.asin, title: r.title, category: r.category, freeShipping: r.freeShipping, importFees: r.importFees, price: r.price, source: r.source }));
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `aif-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  }

  // ============================================================
  //  MAIN
  // ============================================================

  function getCards() {
    // 用 Set 去重
    const seen = new Set();
    const cards = [];
    const selectors = [
      '[data-component-type="s-search-result"]',
      'div[data-asin]:not([data-asin=""])',
      'div.s-result-item',
      'div[data-cel-widget*="search_result"]',
      'div.s-card-container',
      'div[class*="s-result-item"]',
    ];
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        const asin = getASIN(el) || parseASIN(getCardLink(el));
        const key = asin || el.outerHTML.slice(0, 200);
        if (!seen.has(key)) {
          seen.add(key);
          cards.push(el);
        }
      }
    }
    return cards;
  }

  async function run() {
    if (isScanning) return lastResults;
    isScanning = true;
    removePanel();

    const cards = getCards();
    console.log('[AIF] Found', cards.length, 'product cards on', location.href);

    if (!cards.length) {
      showPanel(`<div style="position:fixed;top:10px;right:10px;z-index:99999;background:#c33;color:#fff;padding:6px 12px;border-radius:6px;font:12px/1.5 Arial,sans-serif;">🇮🇱 AIF: No product cards found</div>`);
      isScanning = false;
      return [];
    }

    // 确保卡片 relative
    cards.forEach(c => {
      if (getComputedStyle(c).position === 'static') c.style.position = 'relative';
    });

    lastResults = await scanAll(cards);

    for (const r of lastResults) addLabel(r.card, r);
    showSummary(lastResults);

    const stats = { best:0, good:0, bad:0, unknown:0 };
    lastResults.forEach(r => stats[r.category]++);
    console.log('[AIF] Done:', stats);

    isScanning = false;
    return lastResults;
  }

  // ============================================================
  //  INIT
  // ============================================================

  // 立即显示加载确认
  console.log('[AIF] Content script loaded on', location.href);

  function init() {
    const cards = getCards();
    console.log('[AIF] init — found', cards.length, 'cards');
    if (cards.length > 0) {
      showLoaded(cards.length);
    } else {
      showPanel(`<div style="position:fixed;top:10px;right:10px;z-index:99999;background:#888;color:#fff;padding:6px 12px;border-radius:6px;font:12px/1.5 Arial,sans-serif;">🇮🇱 AIF: 0 cards · <a id="__amzn_il_retry" style="color:#ff0;cursor:pointer;text-decoration:underline;">Retry</a></div>`);
      const btn = document.getElementById('__amzn_il_retry');
      if (btn) btn.onclick = run;
    }
  }

  if (document.readyState === 'complete') {
    setTimeout(init, SCAN_DELAY);
  } else {
    window.addEventListener('load', () => setTimeout(init, SCAN_DELAY));
  }

  // 响应 popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'scan') { run().then(r => sendResponse({ ok: true, count: r.length })); return true; }
    if (msg.action === 'export') { exportJSON(lastResults); sendResponse({ ok: true }); }
  });

})();
