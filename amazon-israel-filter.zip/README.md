# Amazon Israel Filter

Chrome extension that scans Amazon search results to identify products with **free shipping** and **no import fees** to Israel.

## Features

- **Instant card parsing** — reads delivery info directly from search result cards (zero extra requests)
- **Detail page fallback** — fetches product detail pages when card info is incomplete
- **Color-coded labels** on each product card:
  - Green `Best` — free shipping + tax-free
  - Yellow `Good` — free shipping OR tax-free
  - Red `Bad` — neither
  - Grey `?`  — unknown
- **One-click export** to JSON
- **Concurrency control** — parallel scanning with rate-limit protection

## Install

1. Clone or download this repo
2. Chrome → `chrome://extensions` → toggle **Developer mode** ON
3. Click **Load unpacked** → select the project folder
4. Open `amazon.com/s?k=...` → auto-scans after 2 seconds

**Important:** Log in to Amazon and set your delivery address to Israel for accurate results.

## Project Structure

```
├── manifest.json      # Chrome Extension (Manifest V3)
├── content.js         # Content script — scan engine + UI labels
├── background.js      # Service worker — install log
├── style.css          # Label color styles
├── popup.html / .js   # Toolbar popup (Scan / Export)
├── lib/
│   └── parser.js      # Standalone parser (reference implementation)
└── icons/             # Extension icons
```

## How It Works

```
Search page → get product cards → Channel A (card inline text)
    ├── sufficient? → classify → tag card
    └── not enough  → Channel B (fetch detail page) → classify → tag card
```

Classification rules:
| Condition | Category |
|-----------|----------|
| Import Fees = $0 + Free Shipping | **best** |
| Import Fees = $0 OR Free Shipping | **good** |
| Has Import Fees + paid shipping | **bad** |
| Cannot determine | **unknown** |

## Supported Amazon sites

- `amazon.com`
- `amazon.de`
- `amazon.co.uk`

Edit `manifest.json` → `content_scripts.matches` to add more.

## Development

```bash
# Load as unpacked extension
chrome://extensions → Developer mode → Load unpacked → select this folder

# After making changes
chrome://extensions → click refresh icon on the extension card

# Debug
Open Amazon search → F12 → Console → look for [AIF] logs
```

## License

MIT
