/**
 * Service worker — 安装/更新日志 & 消息中继
 */

chrome.runtime.onInstalled.addListener(({ reason }) => {
  console.log('[AIF] Extension installed/updated:', reason);
});

chrome.runtime.onStartup.addListener(() => {
  console.log('[AIF] Browser started — extension active');
});

// 监听来自 content script 的消息（备用通道）
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'log') {
    console.log('[AIF]', msg.data);
  }
});
